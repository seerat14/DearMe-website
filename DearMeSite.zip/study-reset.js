let timeLeft = 1500;
let timer;
let isRunning = false;

function startTimer() {
  if (isRunning) return;
  isRunning = true;
  timer = setInterval(() => {
    if (timeLeft <= 0) {
      clearInterval(timer);
      document.getElementById("timerDisplay").innerText = "Time's up!";
      showSuccess();
    } else {
      timeLeft--;
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      document.getElementById("timerDisplay").innerText = \`\${minutes.toString().padStart(2, '0')}:\${seconds.toString().padStart(2, '0')}\`;
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(timer);
  timeLeft = 1500;
  isRunning = false;
  document.getElementById("timerDisplay").innerText = "25:00";
}

function showSuccess() {
  alert("Pomodoro session complete! Great job!");
}

function showTip() {
  const tips = [
    "Break big tasks into tiny steps.",
    "Do one thing at a time.",
    "You don’t need to be perfect to start.",
    "Stretch. Hydrate. Breathe."
  ];
  const randomTip = tips[Math.floor(Math.random() * tips.length)];
  document.getElementById("tipText").innerText = randomTip;
}

function playCalmingSound() {
  const audio = new Audio('https://cdn.pixabay.com/download/audio/2022/03/22/audio_c8ff165aa0.mp3');
  audio.play();
}
