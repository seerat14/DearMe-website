console.log("Welcome to DearMe – your cozy space ✨");
document.querySelector("form")?.addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Your mood has been logged! Take a deep breath.");
});
